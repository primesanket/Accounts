<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($invoiceData['invoice_name']); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 14px;
            color: #000;
            margin: 0;
            padding: 0;
        }

        .header {
            text-align: left;
            /* border-top: 5px solid #888; */
            position: relative;
            margin: 0;
            padding-top: 10px;
        }

        .header img {
            max-width: 250px;
        }

        .header .invoice_label {
            position: absolute;
            width: auto;
            height: 50px;
            /* background: red; */
            right: 0;
            text-align: right;
            border-left: 5px solid #888;
            padding-left: 15px;
        }

        .header .invoice_label h1 {
            margin-top: 8px;
            font-weight: 700;
            font-size: 26px;
        }

        .no-border-table,
        .no-border-table th,
        .no-border-table td {
            border: none;
        }

        .info-section {
            width: 100%;
            margin-bottom: 20px;
        }

        .info-section table {
            width: 100%;
            border: none;
        }

        .company-info,
        .invoice-info {
            width: 48%;
        }

        .company-info p,
        .invoice-info p,
        .bank-details p,
        .signature p {
            margin: 0;
            font-size: 12px;
            line-height: 1.6;
        }


        .company-info {
            font-size: 12px;
        }

        .company-info h3 {
            font-size: 17px;
        }

        .invoice-info {
            width: 230px;
            text-align: right;
            font-size: 12px;
            /* background: red; */
            position: absolute;
            right: 0;
            padding-bottom: 13px;
        }

        .invoice-info p {
            font-size: 14px;
        }

        .bill-to {
            width: 100%;
            margin-bottom: 20px;
            border-left: 5px solid #888;
            padding-left: 8px;
            margin-top: -10px;
        }


        .bill-to p {
            margin: 0;
            font-size: 15px;
            line-height: 1.4;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        .list-wrapper {
            /* background-color: red; */
            min-height: 302px;
        }

        .list td,
        .list th {
            text-align: center;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 8px;
            text-align: left;
            font-size: 12px;
        }

        th {
            background-color: #e0e0e0;
        }

        .bank-details {
            font-size: 12px;
        }

        .signature {
            text-align: right;
            font-size: 12px;
            margin-top: 0px;
        }

        .footer {
            text-align: center;
            font-size: 12px;
            margin-top: 40px;
            border-top: 2px solid #000;
            padding-top: 10px;
        }
    </style>
</head>

<body>
    <div class="header">
        <img src="images/logo/primento.png" alt="Logo">
        <div class="invoice_label">
            <h1><?php echo e($invoiceData['invoice_name']); ?></h1>
        </div>
    </div>


    <div class="info-section">

        <table class="no-border-table">
            <tr>
                <td class="company-info">
                    <h3 style="margin-bottom: 0;margin: 0"><strong><?php echo e($invoiceData['company']); ?></strong></h3>
                    <p>GST NO: <?php echo e($invoiceData['gst_no']); ?></p>
                    <p>PAN NO: <?php echo e($invoiceData['pan_no']); ?></p>
                    <p style="margin-bottom: 5px;">LUT NO: <?php echo e($invoiceData['lut_no']); ?></p>
                    <p style="line-height: 1.1;"><?php echo e($invoiceData['address_1']); ?><br><?php echo e($invoiceData['address_2']); ?></p>
                    <p style="line-height: 1.3;"><?php echo e($invoiceData['contact_no']); ?></p>
                </td>
                <td style="text-align: right;position:relative;">
                    <div class="invoice-info">
                        <p>Date: <strong><?php echo e($invoiceData['date']); ?></strong></p>
                        <p>Invoice No: <strong><?php echo e($invoiceData['invoice_no']); ?></strong></p>
                    </div>
                </td>
            </tr>
        </table>
    </div>

    <div class="bill-to">
        <h3 style="padding: 0;margin:0;">Bill To:</h3>
        <p><?php echo e($invoiceData['bill_to']['name']); ?></p>
        <p><?php echo e($invoiceData['bill_to']['address']); ?></p>
        <p><?php echo e($invoiceData['bill_to']['gst_no']); ?></p>
    </div>

    <div class="list-wrapper">

        <div class="list">
            <table>
                <thead>
                    <tr>
                        <th style="width: 30px;">No</th>
                        <th>Description of Goods</th>
                        <th style="width: 30px;">Qty</th>
                        <th style="width: 80px;">Unit Price</th>
                        <th style="width: 80px;">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $invoiceData['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->last): ?>
                    <tr style="">
                        <td style="border-bottom:none;border-top:none;height:29px;"><?php echo e($index + 1); ?></td>
                        <td style="border-bottom:none;border-top:none;text-align: left;padding:0 auto;"><strong><?php echo e($item['product_name']); ?></strong><br><span style="font-size: 10px;"><?php echo e($item['description']); ?></span></td>
                        <td style="border-bottom:none;border-top:none;"><?php echo e($item['quantity']); ?></td>
                        <td style="border-bottom:none;border-top:none;"><?php echo e(number_format($item['rate'], 2)); ?> </td>
                        <td style="border-bottom:none;border-top:none;"><?php echo e(number_format($item['amount'], 2)); ?></td>
                    </tr>
                    <?php else: ?>
                    <tr>
                        <td style="border-bottom:none;border-top:none;height:29px;"><?php echo e($index + 1); ?></td>
                        <td style="border-bottom:none;border-top:none;text-align: left;padding:0 auto;"><strong><?php echo e($item['product_name']); ?></strong><br><span style="font-size: 10px;"><?php echo e($item['description']); ?></span></td>
                        <td style="border-bottom:none;border-top:none;"><?php echo e($item['quantity']); ?></td>
                        <td style="border-bottom:none;border-top:none;"><?php echo e(number_format($item['rate'], 2)); ?> </td>
                        <td style="border-bottom:none;border-top:none;"><?php echo e(number_format($item['amount'], 2)); ?></td>
                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php for($i = 0; $i < (6 - sizeof($invoiceData['items'])); $i++): ?>
                        <tr style="">
                        <td style="border-bottom:none;border-top:none;height:29px;"></td>
                        <td style="border-bottom:none;border-top:none;text-align: left;padding:0 auto;"></td>
                        <td style="border-bottom:none;border-top:none;"></td>
                        <td style="border-bottom:none;border-top:none;"></td>
                        <td style="border-bottom:none;border-top:none;"></td>
                        </tr>
                        <?php endfor; ?>
                </tbody>
            </table>
        </div>

    </div>
    <table>
        <tbody>
            <tr>
                <td style="background-color:#e0e0e0;"></td>
                <td style="width: 80px;border-right:none;text-align: center;background-color:#e0e0e0;">Invoice Total</td>
                <td style="width: 80px;background-color:#e0e0e0;text-align: center;"><strong><?php echo e(number_format($invoiceData['invoice_total'], 2)); ?></strong></td>
            </tr>
        </tbody>
    </table>

    <div class="info-section">
        <p>Please kindly make a payment in below bank account:</p>
        <table class="no-border-table">
            <tr>
                <td style="padding-left: 0;">
                    <div class="bank-details">
                        <p>Bank: <?php echo e($invoiceData['bank_details']['bank']); ?></p>
                        <p>Branch: <?php echo e($invoiceData['bank_details']['branch']); ?></p>
                        <p>Account Name: <?php echo e($invoiceData['bank_details']['account_name']); ?></p>
                        <p>Account Number: <?php echo e($invoiceData['bank_details']['account_number']); ?></p>
                        <p>IFSC Code: <?php echo e($invoiceData['bank_details']['ifsc_code']); ?></p>
                    </div>
                </td>
            </tr>
        </table>
        <p style="margin-top: 60px;"><center style="color: red;">Any transfer or currency exchange charges are payable by clients. please transfer according.</center></p>
    </div>

    <div class="footer">
        <p>Please contact us regarding payment options. thank you for your business.</p>
    </div>
</body>

</html><?php /**PATH C:\laragon\www\prime_accounting\resources\views\invoices\PF.blade.php ENDPATH**/ ?>